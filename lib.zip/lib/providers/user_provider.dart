import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../services/notification_service.dart';

class UserProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final StudyNotificationService _notificationService =
      StudyNotificationService();
  UserModel? _user;

  UserModel? get user => _user;

  // Load user data from Firestore
  Future<void> loadUserData(String userId) async {
    try {
      final userDoc = await _firestore.collection('users').doc(userId).get();
      if (userDoc.exists) {
        _user = UserModel.fromJson(userDoc.data()!);
        notifyListeners();
      }
    } catch (e) {
      print('Error loading user data: $e');
    }
  }

  // Sign up a new user
  Future<void> signUp(String email, String password, String name, String level,
      String year) async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = UserModel(
        id: userCredential.user!.uid,
        name: name,
        level: level,
        year: year,
        avatar: 'assets/avatars/default.png',
        chapters: [],
      );

      await _firestore.collection('users').doc(user.id).set(user.toJson());
      _user = user;
      notifyListeners();
    } catch (e) {
      print('Error during sign up: $e');
      throw e;
    }
  }

  // Log in an existing user
  Future<void> login(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      await loadUserData(userCredential.user!.uid);
    } catch (e) {
      print('Error during login: $e');
      throw e;
    }
  }

  // Log out the user
  Future<void> logout() async {
    try {
      await _auth.signOut();
      _user = null;
      notifyListeners();
    } catch (e) {
      print('Error during logout: $e');
      throw e;
    }
  }

  Future<void> updateUser(UserModel updatedUser) async {
    try {
      await _firestore
          .collection('users')
          .doc(updatedUser.id)
          .update(updatedUser.toJson());
      _user = updatedUser;
      notifyListeners();
    } catch (e) {
      print('Error updating user: $e');
      throw e;
    }
  }

  Future<void> saveUserProgress(UserModel user) async {
    final progressBox = Hive.box<UserModel>('progress');
    await progressBox.put(user.id, user);
  }

  Future<UserModel?> getUserProgress(String userId) async {
    final progressBox = Hive.box<UserModel>('progress');
    return progressBox.get(userId);
  }

  // Schedule user notifications
  Future<void> _scheduleUserNotifications() async {
    if (_user == null) return;

    final prefs = await SharedPreferences.getInstance();
    final studyRemindersEnabled = prefs.getBool('study_reminders') ?? true;

    if (studyRemindersEnabled) {
      // Schedule morning reminder
      final morningHour = prefs.getInt('morning_reminder_hour') ?? 10;
      final morningMinute = prefs.getInt('morning_reminder_minute') ?? 0;
      await _notificationService.scheduleDailyStudyReminder(
        TimeOfDay(hour: morningHour, minute: morningMinute),
        type: 'morning',
      );

      // Schedule evening reminder
      final eveningHour = prefs.getInt('evening_reminder_hour') ?? 18;
      final eveningMinute = prefs.getInt('evening_reminder_minute') ?? 0;
      await _notificationService.scheduleDailyStudyReminder(
        TimeOfDay(hour: eveningHour, minute: eveningMinute),
        type: 'evening',
      );
    }
  }
}
