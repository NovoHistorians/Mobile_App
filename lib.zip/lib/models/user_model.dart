import 'package:flutter/material.dart';
import 'chapter_model.dart';

class UserModel with ChangeNotifier {
  String _id;
  String _name;
  String _level;
  String _year;
  String _avatar;
  List<Chapter> _chapters;

  UserModel({
    required String id,
    required String name,
    required String level,
    required String year,
    required String avatar,
    required List<Chapter> chapters,
  })  : _id = id,
        _name = name,
        _level = level,
        _year = year,
        _avatar = avatar,
        _chapters = chapters;

  String get id => _id;
  String get name => _name;
  String get level => _level;
  String get year => _year;
  String get avatar => _avatar;
  List<Chapter> get chapters => _chapters;

  set name(String value) {
    _name = value;
    notifyListeners();
  }

  set level(String value) {
    _level = value;
    notifyListeners();
  }

  set year(String value) {
    _year = value;
    notifyListeners();
  }

  set avatar(String value) {
    _avatar = value;
    notifyListeners();
  }

  set chapters(List<Chapter> value) {
    _chapters = value;
    notifyListeners();
  }

  Map<String, dynamic> toJson() {
    return {
      'id': _id,
      'name': _name,
      'level': _level,
      'year': _year,
      'avatar': _avatar,
      'chapters': _chapters.map((chapter) => chapter.toJson()).toList(),
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      name: json['name'],
      level: json['level'],
      year: json['year'],
      avatar: json['avatar'],
      chapters: (json['chapters'] as List)
          .map((chapter) => Chapter.fromJson(chapter))
          .toList(),
    );
  }
}
