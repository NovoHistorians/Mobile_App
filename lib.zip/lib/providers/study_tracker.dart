import 'package:cloud_firestore/cloud_firestore.dart';

class StudyTracker {
  static Future<void> recordStudySession(String userId) async {
    final userRef = FirebaseFirestore.instance.collection('users').doc(userId);
    await userRef.update({
      'studySessions': FieldValue.arrayUnion([DateTime.now()]),
    });
  }

  static Future<int> getStudyStreak(String userId) async {
    final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(userId).get();
    final studySessions = userDoc.data()?['studySessions'] ?? [];
    // Logic to calculate streak
    return studySessions.length; // Replace with actual streak calculation
  }
}
