import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/chat_message_model.dart';

class QuizProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<ChatMessage> _messages = [];
  bool _isTyping = false;
  List<String> _suggestions = [];

  List<ChatMessage> get messages => _messages;
  bool get isTyping => _isTyping;
  List<String> get suggestions => _suggestions;

  Future<void> loadMessages(String userId) async {
    try {
      QuerySnapshot messageSnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('messages')
          .orderBy('timestamp', descending: true)
          .limit(50)
          .get();
      _messages = messageSnapshot.docs
          .map(
              (doc) => ChatMessage.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
      notifyListeners();
    } catch (e) {
      print('Error loading messages: $e');
    }
  }

  Future<void> addMessage(String userId, String text, bool isUser) async {
    try {
      final ttl = DateTime.now().add(Duration(days: 5)); // Set TTL to 5 days
      final message = ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: text,
        isUser: isUser,
        timestamp: DateTime.now(),
      );
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('messages')
          .doc(message.id)
          .set(message.toJson());
      _messages.insert(0, message);
      notifyListeners();

      if (isUser) {
        _isTyping = true;
        notifyListeners();

        // Simulate AI response
        Future.delayed(Duration(seconds: 1), () {
          _isTyping = false;
          String response = 'This is a sample response';
          addMessage(userId, response, false);
        });
      }
    } catch (e) {
      print('Error adding message: $e');
    }
  }

  Future<void> clearMessages(String userId) async {
    try {
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('messages')
          .get()
          .then((snapshot) {
        for (DocumentSnapshot doc in snapshot.docs) {
          doc.reference.delete();
        }
      });
      _messages.clear();
      notifyListeners();
    } catch (e) {
      print('Error clearing messages: $e');
    }
  }
}
