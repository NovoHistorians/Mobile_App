class Quiz {
  final String id;
  final String title;
  final List<Question> questions;
  int score;

  Quiz({
    required this.id,
    required this.title,
    required this.questions,
    this.score = 0,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'questions': questions.map((question) => question.toJson()).toList(),
      'score': score,
    };
  }

  factory Quiz.fromJson(Map<String, dynamic> json) {
    return Quiz(
      id: json['id'],
      title: json['title'],
      questions: (json['questions'] as List)
          .map((question) => Question.fromJson(question))
          .toList(),
      score: json['score'],
    );
  }
}

class Question {
  final String id;
  final String questionText;
  final List<String> choices;
  final String correctAnswer;

  Question({
    required this.id,
    required this.questionText,
    required this.choices,
    required this.correctAnswer,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'questionText': questionText,
      'choices': choices,
      'correctAnswer': correctAnswer,
    };
  }

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'],
      questionText: json['questionText'],
      choices: List<String>.from(json['choices']),
      correctAnswer: json['correctAnswer'],
    );
  }
}
