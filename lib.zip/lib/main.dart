import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:novo_historians/screens/contact_info_screen.dart';
import 'package:novo_historians/screens/help_support_screen.dart';
import 'package:novo_historians/screens/privacy_policy_screen.dart';
import 'package:novo_historians/screens/terms_service_screen.dart';
import 'package:provider/provider.dart';
import 'models/quiz_model.dart';
import 'providers/user_provider.dart';
import 'screens/chatbot_screen.dart';
import 'screens/landing_screen.dart';
import 'screens/notification_screen.dart.dart';
import 'screens/profile_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/home_screen.dart';
import 'utils/theme.dart';
import 'firebase_options.dart';
import 'package:hive/hive.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseFirestore.instance.settings = Settings(persistenceEnabled: true);
  Hive.registerAdapter(QuizAdapter()); // Register Quiz adapter
  await Hive.openBox<Quiz>('quizzes'); // Open a box for quizzes
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserProvider()),
        // Add other providers here
      ],
      child: AlgerianHistoryApp(),
    ),
  );
}

class AlgerianHistoryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Algerian History',
      theme: appTheme,
      navigatorKey: navigatorKey,
      initialRoute: '/',
      routes: {
        '/': (context) => AuthWrapper(), // Use AuthWrapper as the initial route
        '/welcome': (context) => WelcomeScreen(),
        '/home': (context) => HomeScreen(),
        '/chat': (context) => ChatbotScreen(),
        '/profile': (context) => ProfileScreen(),
        '/notification': (context) => NotificationSettingsScreen(),
        '/help': (context) => HelpSupportScreen(),
        '/terms': (context) => TermsServiceScreen(),
        '/privacy': (context) => PrivacyPolicyScreen(),
        '/contact': (context) => ContactInfoScreen(),
      },
    );
  }
}

class AuthWrapper extends StatelessWidget {
  Future<void> checkSessionExpiry() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final metadata = user.metadata;
      final lastSignIn = metadata.lastSignInTime;
      final now = DateTime.now();
      final difference = now.difference(lastSignIn!);
      if (difference.inDays > 30) {
        // Force the user to log in again
        await FirebaseAuth.instance.signOut();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          // Check if the user is logged in
          final User? user = snapshot.data;
          if (user != null) {
            // User is logged in, redirect to home screen
            return HomeScreen();
          } else {
            // User is not logged in, redirect to landing screen
            return LandingScreen();
          }
        }
        // Show a loading indicator while checking authentication state
        return Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }
}
