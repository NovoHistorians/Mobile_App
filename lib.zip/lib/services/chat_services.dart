// services/chat_service.dart
import 'package:dio/dio.dart';

class ChatService {
  final Dio _dio = Dio();
  final String _modelEndpoint = 'YOUR_MODEL_ENDPOINT';

  Future<String> getBotResponse(
      String message, String level, String year) async {
    try {
      final response = await _dio.post(
        _modelEndpoint,
        data: {
          'message': message,
          'level': level,
          'year': year,
          'type': 'chat'
        },
      );
      return response.data['response'];
    } catch (e) {
      print('Error getting bot response: $e');
      return 'Sorry, I encountered an error. Please try again.';
    }
  }
}
